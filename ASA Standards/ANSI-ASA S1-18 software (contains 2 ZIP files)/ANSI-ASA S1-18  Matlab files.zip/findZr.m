function findZr(inputdata,outfilenm,geomtr,C0)
%**************************************************************

% Select geometry

if geomtr==1
    HS=0.33;      % source height
    HRT=0.46;     % upper microphone
    HRB=0.23;     % lower microphone
    RANGE=1.75;
elseif geomtr==2
    HS=0.20;
    HRT=0.20;
    HRB=0.05;
    RANGE=1.0;
end

% ***************************************************       
       freq=inputdata(:,1);
       rTF=inputdata(:,2);
       xTF=inputdata(:,3);
      
      TFm=rTF-i*xTF;
%      C0=343;
      
      NPTS=length(freq);
      XACC=0.000001;   %convergence criteria
      JMAX=20;     %number of interations
      
      rz=zeros(1,NPTS);
      iz=zeros(1,NPTS);
  
%     initial guess
      beta=0.0-i*0.0;
             
      for JJ=1:NPTS
      
      K0=2.*pi*freq(JJ)/C0;
	  itercount=0;
      
	for I=1:JMAX

    [TFc, DTFc]=leveldiff(K0,beta,HRT,HRB,HS,RANGE);
    
    DX=(TFc-TFm(JJ))/DTFc;
	beta=beta-DX;
    
    itercount=itercount+1;
    
        if abs(DX/beta)<XACC
            break
        end
   
    end
    
        if itercount==JMAX
            disp('no convergence at');
            frequency=freq(JJ)
            break
        end
  
         if abs(beta)>1000
            disp('abs(beta)>1000 at');
            frequency=freq(JJ)
            break
         end

         found=beta;   %admittance
         
      rz(JJ)=real(1/found);
      iz(JJ)=imag(1/found);
            
      end
      
      outputdata=[freq,rz',iz'];
 
eval(['save ',outfilenm,' outputdata -ascii']);

figure(1);
semilogx(freq,rz,freq,iz,'--');
axis([100 4000 0 25]);
ylabel('R and X');
xlabel('freq');

