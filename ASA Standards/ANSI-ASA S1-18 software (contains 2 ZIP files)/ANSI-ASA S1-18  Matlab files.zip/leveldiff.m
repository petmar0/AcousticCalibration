      function [TF, DTF]=leveldiff(K0,beta,HRT,HRB,HS,RANGE)
  % ******************************************************************       
      SEP=sqrt(RANGE*RANGE+(HRT-HS)^2);
      SEP2=sqrt(RANGE*RANGE+(HRT+HS)^2);
      SEP3=sqrt(RANGE*RANGE+(HRB-HS)^2);
      SEP4=sqrt(RANGE*RANGE+(HRB+HS)^2);

      P1=exp(i*K0*SEP)/SEP;
      P2=exp(i*K0*SEP2)/SEP2;
      P3=exp(i*K0*SEP3)/SEP3;
      P4=exp(i*K0*SEP4)/SEP4;
      
	[AQ1 DQ1]=reflec(K0,beta,HRT,HS,RANGE);
	[AQ2 DQ2]=reflec(K0,beta,HRB,HS,RANGE);
    
      PP1=P1+AQ1*P2;
	PP2=P3+AQ2*P4;
      TF=PP1/PP2;
	
      TP1=DQ1*P2;
	TP2=DQ2*P4;
      DTF=TF*(TP1/PP1-TP2/PP2);