function [Q DQ]=reflec(K0,beta,HR,HS,R)
%**********************************************************************
% Calcule le coefficient de reflexion complexe de l'onde spherique

    H=HS+HR;
    R2=sqrt(H*H+R*R);
    cth=H/R2;
    
	Rp=(cth-beta)/(cth+beta);
    
	w=sqrt(i*K0*R2/2)*(cth+beta);
	rew=real(w);
	imw=imag(w);
   argw=atan2(imw,rew);
%
%****************************************************************
% Must ensure that -pi/4<argw<3pi/4	(see M. Stinson JASA Vol. 98).
%****************************************************************
% In matlab, the result of atan2(y,x) is in the interval [-pi,pi].
%****************************************************************
%
	k=find(argw>(3*pi/4));
	argw(k)=argw(k)-pi;
	w(k)=abs(w(k))*exp(i*argw(k));

	k=find(argw<-(pi/4));
	argw(k)=argw(k)+pi;
	w(k)=abs(w(k))*exp(i*argw(k));

    tau=w/(cth+beta);
    
    FdeW=FofW(w);
	
    Q=Rp+(1-Rp)*FdeW;   
    DQ=2*tau*((FdeW-1)/w-2*tau*beta*FdeW);

    

