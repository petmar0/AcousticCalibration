function fw=FofW(w)

% ********************************************************************
% * CE SOUS-PROGRAMME CALCULE LA FONCTION F(w) A PARTIR
% * DU DEVELOPPEMENT ASSYMPTOTIQUE CLASSIQUE
% ********************************************************************

m=length(w);
fw=zeros(1,m);

for k=1:m
	if abs(w(k))<=4		%series for small w
		bk=0;
		sum=1+i*0;
		term=sum;
		while abs(term)>=0.000001
			bk=bk+1;          
			term=(term*w(k)^2/bk)*((2*bk-1)/(2*bk+1));
			sum=sum+term;
		end		
	fw(k)=1+i*sqrt(pi)*w(k)*exp(-w(k)^2)-2*w(k)^2*exp(-w(k)^2)*sum;
   
	else			     %series for w > 4
		bk=0;
		sum=1/(2*w(k)^2);
		term=sum;
		while abs(term)>=0.000001
			bk=bk+1;
			term=term*(2*bk+1)/(2*w(k)^2);
			sum=sum+term;
      end
      
		if imag(w(k))<0
		fw(k)=2*i*sqrt(pi)*w(k)*exp(-w(k)^2)-sum;
		else
		fw(k)=-sum;
		end

	end
end