%     PROGRAMME impLD.m
%*********************************************************************
% Main programme for direct deduction of ground impedance
% from complex level difference measurements (November 2005).
% Modified for copatibility with the final version of ANSI-S1.18 (June 2009)
%*********************************************************************

disp('   ');
disp(' Program assumes exp(-iwt) time convension');
disp('   ');
disp(' The input file must be a 3-colunm text file containing: Frequency(Hz), realT, imagT');
disp('   ');
disp(' where T = real(T) + j*imag(T) given by equation (C1)');
disp('   ');
disp(' Enter input and output data file names with extension, e.g., Tgrass03.txt and Zgrass03.txt');
disp('   ');

infilenm=input('     ENTER INPUT FILE NAME: ','s');
disp('   ');
outfilenm=input('     ENTER OUTPUT FILE NAME: ','s');

disp('   ');
disp(' Enter geometry= A or B (note upper case)');
disp('   ');

geometry=input('     ENTER GEOMETRY: ','s');

disp('   ');
C00=input('     ENTER Speed of Sound in m/s: ','s');

disp('   ');disp(' Hit any key to run program or press Ctrl C to abort');
pause

eval(['load ',infilenm,' -ascii']);

[if1,if2,if3]=fileparts(infilenm);
inputdata=eval(if2);

A=1;
B=2;

geomtr=eval(geometry);
C0=eval(C00);
findZr(inputdata,outfilenm,geomtr,C0);

clear all


